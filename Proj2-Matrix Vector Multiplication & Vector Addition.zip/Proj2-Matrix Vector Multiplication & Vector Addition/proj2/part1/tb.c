#include <stdio.h>
#include <time.h>

int main() {
  int desiredInputs = 10;
  srand(time(NULL)); // Set random seed based on current time

  FILE *inputData1, *expectedOutput1;

  inputData1 = fopen("inputData1", "w");
  expectedOutput1 = fopen("expectedOutput1", "w");

int i,j,k,z,sum=0;
signed char m[3][3], x[3];
short y[3];


for (z=0; z<desiredInputs; z++) {

for (i = 0; i < 3; i++){
    for (j = 0; j < 3; j++){
	m[i][j]=rand() % 128;
	m[i][j]=m[i][j] & 0x0FF;
	fprintf(inputData1, "%x \n", m[i][j]);
	}
}

for (k = 0; k < 3; k++){
	x[k]=rand() % 128;
	x[k]=x[k] & 0x0FF;
	fprintf(inputData1, "%x\n", x[k]);
	}


for(i=0;i<3;i++){
	for(j=0;j<3;j++){
	sum=sum + m[i][j]*x[j];
	}

	y[i]=sum;
	fprintf(expectedOutput1, "%d \n", y[i]);
	sum=0;
}


}

  fclose(inputData1);
  fclose(expectedOutput1);
}
