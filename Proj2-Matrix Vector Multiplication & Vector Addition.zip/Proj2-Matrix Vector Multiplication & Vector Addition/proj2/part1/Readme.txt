Part1:

Files Included :

part1.sv : Part 1 SV code
tb.c : C fle file for testing
setupdc.tcl : Synthesis File
runsynth.tcl : Synthesis File
outValues: Output from SV file
expectedoutput1: Output of C File
output.txt: Output of Synthesis report

