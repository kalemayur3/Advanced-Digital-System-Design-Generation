Part4:

Files Included :

part4.sv : Part 4 SV code
tb.c : C fle file for testing
setupdc.tcl : Synthesis File
runsynth.tcl : Synthesis File
outValues: Output from SV file
expectedoutput1: Output of C File
output.txt: Output of Synthesis report

