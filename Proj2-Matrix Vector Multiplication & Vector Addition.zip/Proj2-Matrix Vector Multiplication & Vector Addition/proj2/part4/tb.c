#include <stdio.h>
#include <time.h>

int main() {
  int desiredInputs = 10;
  srand(time(NULL)); // Set random seed based on current time

  FILE *inputData1, *expectedOutput1;

  inputData1 = fopen("inputData1", "w");
  expectedOutput1 = fopen("expectedOutput1", "w");

int i,j,k,z,sum=0;
signed char m[4][4], x[4],b[4];
short y[4];


for (z=0; z<desiredInputs; z++) {

for (i = 0; i < 4; i++){
    for (j = 0; j < 4; j++){
	m[i][j]=rand() % 128;
	m[i][j]=m[i][j] & 0xFF;
	fprintf(inputData1, "%x \n", m[i][j]);
	}
}
for (k = 0; k < 4; k++){
	b[k]=rand() % 128;
	b[k]=b[k] & 0xFF;
	fprintf(inputData1, "%x \n", b[k]);
	}

for (k = 0; k < 4; k++){
	x[k]=rand() % 128;
	x[k]=x[k] & 0xFF;
	fprintf(inputData1, "%x \n", x[k]);
	}


for(i=0;i<4;i++){
	for(j=0;j<4;j++){
	sum=sum + m[i][j]*x[j];
	}
	sum=sum+b[i];
	y[i]=sum;
	fprintf(expectedOutput1, "%d \n", y[i]);
	sum=0;
}


}

  fclose(inputData1);
  fclose(expectedOutput1);
}
