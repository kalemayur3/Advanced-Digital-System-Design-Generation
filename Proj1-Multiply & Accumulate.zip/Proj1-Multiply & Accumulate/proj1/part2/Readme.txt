Part2:

Files Included :

part2.sv : Part2 SV code
tb_check : C fle file for testing
setupdc.tcl : Synthesis File
runsynth.tcl : Synthesis File
outValues: Output from SV file
expectedoutput: Output of C File
output.txt: Output of Synthesis report

Simulation commands: 
To simulate code at command line
vlog part2.sv
vsim tb_part2_mac -c -do "run -all"

To simulate code using ModelSiim GUI
vlog +acc part2.sv	             
vsim tb_part2_mac &
