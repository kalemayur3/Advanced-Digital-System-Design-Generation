#include <stdio.h>
	signed char i, j,a,b;
	short f = 0,temp=0,q3=0;
	int overflow=0,valid_in=0,reset=0;
void comp(signed char i,signed char j,int reset ,int valid_in);
void main() {
	
	printf("0\n");
	printf("0\n");
	printf("0\n");
	printf("0\n");
	printf("0\n");
	printf("0\n");
	printf("0\n");
	printf("0\n");
	printf("0\n");

	valid_in=1;reset=0;
	for (i = 100; i <= 105; i += 5) {
		for (j = 100; j <= 110; j += 5) {
			comp(i,j,reset,valid_in);
		}
	}
	
	i=2;j=2;valid_in=0;
	comp(i,j,reset,valid_in);
	
	reset=1;
	comp(i,j,reset,valid_in);	
	
	valid_in=1;reset=0;
	for (i = -105; i > -115; i -= 5) {
			for (j = 100; j <= 110; j += 5) {
				comp(i,j,reset,valid_in);
			}
		}

}
void comp(signed char i,signed char j,int reset,int valid_in)
{

	if(reset==1){
					f=0;
					overflow=0;
					printf("%d\n",0);
					printf("%d\n", f);
					printf("%d\n", overflow);
					printf("0\n");
					printf("0\n");
					printf("0\n");
					printf("0\n");
					printf("0\n");
					printf("0\n");
					
				}				
				else{
					if (valid_in==1){
							q3=i*j;
							f = f + q3;
							printf("%d\n",1);
							printf("%d\n", f);
								if (((temp>=0)&&(q3>0)&&(f<0))||((temp<=0)&&(q3<0)&&(f>0))) {
									overflow = 1;
								} else {
									if(overflow==1){
									overflow=overflow;
									}else{
										overflow=0;
									}			
								}	
							temp=f;	
									
							printf("%d\n", overflow);
						}else{
							f=f;
							printf("%d\n",0);
							printf("%d\n", f);
							printf("%d\n", overflow);
						}
					}		
}

