Part 3:

Directories:

part3_1
Files:
part3_1.sv : SV code for pipelining by adding register between multiplier and adder
runsynth.tcl: Synthesis File
setupdc.tcl: Synthesis File
output.txt: Output of Synthesis report

Simulation commands: 
To simulate code at command line
vlog part3_1.sv
vsim tb_part2_mac -c -do "run -all"

To simulate code using ModelSiim GUI
vlog +acc part3_1.sv	             
vsim tb_part2_mac &
------------------------------------------------------------------------------------
part3_2
Files:
part3_2.sv : SV code for pipelining s=2
runsynth.tcl: Synthesis File
setupdc.tcl: Synthesis File
output.txt: Output of Synthesis report

Simulation commands: 
To simulate code at command line
vlog part3_2.sv
vsim tb_part2_mac -c -do "run -all"

To simulate code using ModelSiim GUI
vlog +acc part3_2.sv	             
vsim tb_part2_mac &
------------------------------------------------------------------------------------
part3_3
Files:
part3_3.sv : SV code for pipelining s=3
runsynth.tcl: Synthesis File
setupdc.tcl: Synthesis File
output.txt: Output of Synthesis report

Simulation commands: 
To simulate code at command line
vlog part3_3.sv
vsim tb_part2_mac -c -do "run -all"

To simulate code using ModelSiim GUI
vlog +acc part3_3.sv	             
vsim tb_part2_mac &
------------------------------------------------------------------------------------
part3_4
Files:
part3_4.sv : SV code for pipelining s=4
runsynth.tcl: Synthesis File
setupdc.tcl: Synthesis File
output.txt: Output of Synthesis report

Simulation commands: 
To simulate code at command line
vlog part3_4.sv
vsim tb_part2_mac -c -do "run -all"

To simulate code using ModelSiim GUI
vlog +acc part3_4.sv	             
vsim tb_part2_mac &
------------------------------------------------------------------------------------
part3_5
Files:
part3_5.sv : SV code for pipelining s=5
runsynth.tcl: Synthesis File
setupdc.tcl: Synthesis File
output.txt: Output of Synthesis report

Simulation commands: 
To simulate code at command line
vlog part3_5.sv
vsim tb_part2_mac -c -do "run -all"

To simulate code using ModelSiim GUI
vlog +acc part3_5.sv	             
vsim tb_part2_mac &
------------------------------------------------------------------------------------




